export { default } from '@/components/auth/ProtectedRoute';
